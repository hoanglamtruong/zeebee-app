================================================================================
          HƯỚNG DẪN CÀI ĐẶT ỨNG DỤNG ANDROID APK TỪ APP.ZEEBEE.VN
================================================================================

Chào mừng bạn đến với hệ sinh thái ứng dụng Offline-First từ Cửa hàng số Zeebee!

1. BẢO MẬT & ĐỘC LẬP:
   - Ứng dụng hoạt động 100% CỤC BỘ (Offline) trên thiết bị của bạn.
   - Không gửi dữ liệu kinh doanh lên đám mây, không thu phí duy trì hàng tháng.

2. CÁC BƯỚC CÀI ĐẶT TRÊN ĐIỆN THOẠI ANDROID:
   - Bước 1: Sao chép file .apk vào điện thoại của bạn (hoặc tải trực tiếp về máy).
   - Bước 2: Nhấn vào file .apk để tiến hành cài đặt.
   - Bước 3: Nếu máy hiển thị cảnh báo "Cài đặt ứng dụng từ nguồn không xác định"
             (Unknown Sources), hãy chọn "Cài đặt" -> Bật cho phép nguồn này
             (Cho phép trình duyệt hoặc trình quản lý tệp cài đặt APK).
   - Bước 4: Nhấn "Cài đặt" (Install) và mở ứng dụng để sử dụng ngay!

3. KÍCH HOẠT BẢN QUYỀN TRỌN ĐỜI:
   - Mặc định ứng dụng cho phép dùng thử miễn phí 7 ngày đầy đủ tính năng.
   - Sau khi mua hàng trên app.zeebee.vn, hệ thống sẽ cấp Mã Kích Hoạt theo
     Mã Thiết Bị (Device ID) của bạn.
   - Mở ứng dụng -> Vào mục Bản Quyền -> Nhập mã ZB-XXXX-XXXX -> Kích hoạt vĩnh viễn.

4. HỖ TRỢ KỸ THUẬT:
   - Website: https://app.zeebee.vn
   - Hotline / Zalo: 0936 898 399
   - Email: contact@zeebee.vn
================================================================================
